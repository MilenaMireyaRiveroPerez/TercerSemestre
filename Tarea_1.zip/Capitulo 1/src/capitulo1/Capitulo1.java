package capitulo1;

public class Capitulo1 {

	public static void main(String[] args) {
		//Milena Rivero 5992400
		System.out.println("Primer  programa de Java!"); 
	}
}
