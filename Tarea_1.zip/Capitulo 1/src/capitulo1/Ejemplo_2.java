package capitulo1;

public class Ejemplo_2 {
	public static void main(String[] args) {
		// Milena Rivero 5992400
		System.out.print("Primer  programa!"); 
		System.out.println("Utilizando JVM con consola!"); 
	}
}
