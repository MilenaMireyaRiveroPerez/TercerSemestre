package capitulo1;

public class Ejemplo_3 {

	public static void main(String[] args) {
		// Milena Rivero 5992400
		System.out.println("Primer\n programa \n de \n Java"); 
	}
}
