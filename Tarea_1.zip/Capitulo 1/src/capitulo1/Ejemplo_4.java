package capitulo1;

public class Ejemplo_4 {

	public static void main(String[] args) {
		// Milena Rivero 5992400
		int i=12;
		int j=10; 
		int suma=i+j;
		int resta= i-j;
		int mult= i*j;
		int div= i/j;
		int modulo= i%j;
		System.out.print("Suma :");
		System.out.println(suma);
		System.out.print("Resta :");
		System.out.println(resta);
		System.out.print("Multiplicacion  :");
		System.out.println(mult);
		System.out.print("Division :");
		System.out.println(div);
		System.out.print("Modulo :");
		System.out.println(modulo);
	}
}
